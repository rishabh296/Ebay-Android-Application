package com.example.hw9androidapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.hw9androidapp.ui.main.SectionsPagerAdapter;

import org.json.JSONObject;

public class prodDetails extends AppCompatActivity {

    String prodId; private RequestQueue mQue;
    JSONObject data;
    SectionsPagerAdapter sectionsPagerAdapter;
    private Toolbar toolbar;
    private ImageView redirect_icon;
    private  LinearLayout loader;
    TabLayout tabs;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{
            super.onCreate(savedInstanceState);
            prodId = getIntent().getStringExtra("prodId");
//            System.out.println("PRODID IN prodDetails - "+prodId);
            setContentView(R.layout.activity_prod_details);
            prepareActionBar();
            loader = findViewById(R.id.detailLoader);
            loader.setVisibility(View.VISIBLE);

            this.sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
            mQue = Volley.newRequestQueue(this);

//            sectionsPagerAdapter.addFragment(new Tab1()); sectionsPagerAdapter.addFragment(new Tab2()); sectionsPagerAdapter.addFragment(new Tab3());
            tabs = findViewById(R.id.tabs);
            tabs.addTab(tabs.newTab().setText("PRODUCT"));
            tabs.addTab(tabs.newTab().setText("SELLER INFO"));
            tabs.addTab(tabs.newTab().setText("SHIPPING"));
            tabs.getTabAt(0).setIcon(R.drawable.information_variant_selected);
            tabs.getTabAt(1).setIcon(R.drawable.ic_seller);
            tabs.getTabAt(2).setIcon(R.drawable.truck_delivery_selected);
            tabs.getTabAt(1).getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.ebay_blue), PorterDuff.Mode.SRC_IN);

            callServer(prodId, this.data);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private SectionsPagerAdapter addFragments(SectionsPagerAdapter sectionsPagerAdapter, String prodId, JSONObject response) {
        Tab1 t1=new Tab1(); Tab2 t2=new Tab2(); Tab3 t3=new Tab3();
        Bundle args = new Bundle();
        args.putString("prodId",prodId);
        args.putString("response",response.toString());
        args.putString("title", getIntent().getStringExtra("title"));
        args.putString("price", getIntent().getStringExtra("price"));
        args.putString("shipping", getIntent().getStringExtra("shipping"));
        args.putString("shippingInfo", getIntent().getStringExtra("shippingInfo"));
        t1.setArguments(args); t2.setArguments(args); t3.setArguments(args);
        sectionsPagerAdapter.addFragment(t1); sectionsPagerAdapter.addFragment(t2); sectionsPagerAdapter.addFragment(t3);
        return sectionsPagerAdapter;
    }

    private void callServer(final String prodId, JSONObject data) {
        String url = "https://ebayhw6.wl.r.appspot.com/singleitem?prodId="+prodId;
        System.out.println("MAKING A FRESH SERVER CALL ON - "+url);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            sectionsPagerAdapter = addFragments(sectionsPagerAdapter,prodId, response);
                            viewPager = findViewById(R.id.view_pager);
                            viewPager.setAdapter(sectionsPagerAdapter);
//                            tabs = findViewById(R.id.tabs);
//                            tabs.removeAllTabs();
                            tabs.setupWithViewPager(viewPager);
                            tabs.getTabAt(0).setIcon(R.drawable.information_variant_selected);
                            tabs.getTabAt(1).setIcon(R.drawable.ic_seller);
                            tabs.getTabAt(2).setIcon(R.drawable.truck_delivery_selected);
                            tabs.getTabAt(1).getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.ebay_blue), PorterDuff.Mode.SRC_IN);

                            loader.setVisibility(View.GONE);
                        } catch (Exception e) {
                            System.out.println("Issue While getting JSON in callServer");
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQue.add(request);
    }


    private void prepareActionBar() {
        toolbar = findViewById(R.id.abar2);
        redirect_icon = findViewById(R.id.redirect_icon);
        redirect_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(getIntent().getStringExtra("itemUrl")!=null && getIntent().getStringExtra("itemUrl").length()>0 && URLUtil.isValidUrl(getIntent().getStringExtra("itemUrl"))){
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getIntent().getStringExtra("itemUrl"))));
                }else{
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ebay.com")));
                }
            }
        });
        toolbar.setTitle(getIntent().getStringExtra("title"));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
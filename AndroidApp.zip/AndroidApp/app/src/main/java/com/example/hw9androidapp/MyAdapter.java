package com.example.hw9androidapp;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.text.HtmlCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyHolder> {

    private Context c;
    private  ArrayList<Model> models;

    public MyAdapter(Context c, ArrayList<Model> models) {
        this.c = c;
        this.models = models;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item,null);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int position) {
        try {
            holder.title.setText(HtmlCompat.fromHtml("<b>" + models.get(position).getTitle() + "</b>", HtmlCompat.FROM_HTML_MODE_LEGACY));
            if (models.get(position).getCondition() == null || models.get(position).getCondition().equals("") || models.get(position).getCondition().length() == 0) {
                holder.condition.setText(HtmlCompat.fromHtml("<b><i>N/A</i></b>", HtmlCompat.FROM_HTML_MODE_LEGACY));
            } else {
                holder.condition.setText(HtmlCompat.fromHtml("<b><i>" + models.get(position).getCondition() + "</i></b>", HtmlCompat.FROM_HTML_MODE_LEGACY));
            }
            holder.price.setText(HtmlCompat.fromHtml("<b>$" + models.get(position).getPrice() + "</b>", HtmlCompat.FROM_HTML_MODE_LEGACY));

            String ship = models.get(position).getShipping();
            if (Double.parseDouble(ship) == 0.0) {
                holder.shipping.setText(HtmlCompat.fromHtml("<b>FREE</b> Shipping", HtmlCompat.FROM_HTML_MODE_LEGACY));
            } else {
                holder.shipping.setText(HtmlCompat.fromHtml("Ships for <b>$" + ship + "</b>", HtmlCompat.FROM_HTML_MODE_LEGACY));
            }
            if (models.get(position).getTop_rated().equals("true")) {
                holder.top_rated.setText(HtmlCompat.fromHtml("<b>Top Rated Listing</b>", HtmlCompat.FROM_HTML_MODE_LEGACY));
                holder.top_rated.setVisibility(View.VISIBLE);
            }

            String url = models.get(position).getImg();
            if (url.equals("https://thumbs1.ebaystatic.com/pict/04040_0.jpg") || url.length() == 0) {
                Picasso.with(c).load(R.drawable.ebay_default).into(holder.img);
            } else {
                Picasso.with(c).load(url).resize(500, 500).into(holder.img);
            }

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(c, prodDetails.class);
                    intent.putExtra("prodId", models.get(position).getProdId());
                    intent.putExtra("title", models.get(position).getTitle());
                    intent.putExtra("price", models.get(position).getPrice());
                    intent.putExtra("itemUrl", models.get(position).getItemUrl());
                    intent.putExtra("shipping", models.get(position).getShipping());
                    intent.putExtra("shippingInfo", models.get(position).getShippingInfo());
                    c.startActivity(intent);
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return models.size();
    }
}

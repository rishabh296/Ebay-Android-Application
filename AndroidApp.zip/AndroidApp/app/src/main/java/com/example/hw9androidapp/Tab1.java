package com.example.hw9androidapp;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.text.HtmlCompat;
import androidx.fragment.app.Fragment;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Tab1 extends Fragment {

    private JSONObject data;
    private TextView sample;
    private LinearLayout gallery;
    private ScrollView scroll;
    String prodId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab1, container, false);
        try {
            this.gallery = (LinearLayout) view.findViewById(R.id.gallin);
            if (getArguments() != null) {
                this.prodId = getArguments().getString("prodId");
                this.data = new JSONObject(getArguments().getString("response"));
                creategallery(gallery, view);
                createFeatures(view);
                createSpecifications(view);
            }
        }catch (Exception e){
            System.out.println("Error in Tab1.java");
            e.printStackTrace();
        }
        return view;
    }

    private void createSpecifications(View view) throws JSONException {
        Boolean featureFlag = false;
        JSONArray specs;
        try {
            specs = data.getJSONObject("Item").getJSONObject("ItemSpecifics").getJSONArray("NameValueList");
        }catch (Exception e){
            specs = null;
        }
        if (specs!=null && specs.length()>0){
            Boolean check = false;
            LinearLayout tl = view.findViewById(R.id.specifications);
            int count=0;
            for (int i=0;i<specs.length();i++){
                if (specs.getJSONObject(i).getString("Name")==null || specs.getJSONObject(i).getJSONArray("Value")==null || specs.getJSONObject(i).getString("Name").equals("Brand")){
                    System.out.println("Continuing FOR - "+specs.getJSONObject(i).getString("Name")+"   "+specs.getJSONObject(i).getJSONArray("Value"));
                    continue;
                }

                featureFlag = true;
                LinearLayout row = new LinearLayout(getContext());
                LinearLayout.LayoutParams tableRowParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT);
                int leftMargin = 150;
                int topMargin = 5;
                int rightMargin = 0;
                int bottomMargin = 0;
                tableRowParams.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);
                row.setLayoutParams(tableRowParams);
                row.setOrientation(LinearLayout.HORIZONTAL);

                TextView tv = new TextView(getContext());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                tv.setLayoutParams(lp);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
//                tv.setText(HtmlCompat.fromHtml("<b style=\"color:#000000;\">\u2022 "+specs.getJSONObject(i).getString("Name")+"</b> : "+specs.getJSONObject(i).getJSONArray("Value").getString(0), HtmlCompat.FROM_HTML_MODE_LEGACY));
                tv.setText(HtmlCompat.fromHtml("\u2022 "+specs.getJSONObject(i).getJSONArray("Value").getString(0), HtmlCompat.FROM_HTML_MODE_LEGACY));
                row.addView(tv);
                tl.addView(row);
                count+=1;
                if (count==5){
                    break;
                }
            }
        }

        if (!featureFlag){
            view.findViewById(R.id.specParent).setVisibility(View.GONE);
        }


    }

    private void createFeatures(View view) throws JSONException {
        Boolean featureFlag = false;
        LinearLayout tl = (LinearLayout) view.findViewById(R.id.addFeatures);
        String subtitle;
        try {
            subtitle = data.getJSONObject("Item").getString("Subtitle");
        }catch (Exception e){
            subtitle = null;
        }
        if (subtitle!=null){
            featureFlag = true;
            LinearLayout row = new LinearLayout(getContext());
            LinearLayout.LayoutParams tableRowParams= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,TableLayout.LayoutParams.WRAP_CONTENT);
            int leftMargin=125;int topMargin=5;int rightMargin=0;int bottomMargin=0;
            tableRowParams.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);
            row.setLayoutParams(tableRowParams);
            row.setOrientation(LinearLayout.HORIZONTAL);

            TextView tv = new TextView(getContext());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            tv.setLayoutParams(lp);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP,16);
            tv.setText(HtmlCompat.fromHtml("<span style=\"color:#000000;\">Subtitle</span>", HtmlCompat.FROM_HTML_MODE_LEGACY));
            row.addView(tv);

            tv = new TextView(getContext());
            lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(60,0,0,0);
            tv.setLayoutParams(lp);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP,14);
            tv.setText(HtmlCompat.fromHtml(subtitle, HtmlCompat.FROM_HTML_MODE_LEGACY));
            row.addView(tv);
            tl.addView(row);
        }

        JSONArray brand;
        try {
            brand = data.getJSONObject("Item").getJSONObject("ItemSpecifics").getJSONArray("NameValueList");
        }catch (Exception e){
            brand = null;
        }
        if (brand!=null && brand.length()>0){
            String val="";
            Boolean check = false;
            for (int i=0;i<brand.length();i++){
                if (brand.getJSONObject(i).getString("Name")!=null && brand.getJSONObject(i).getJSONArray("Value")!=null && brand.getJSONObject(i).getString("Name").equals("Brand")){
                    val = brand.getJSONObject(i).getJSONArray("Value").getString(0);
                    check=true;
                    break;
                }
            }

            if (check) {
                featureFlag = true;
                LinearLayout row = new LinearLayout(getContext());
                LinearLayout.LayoutParams tableRowParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT);
                int leftMargin = 125; int topMargin = 5; int rightMargin = 0; int bottomMargin = 0;
                tableRowParams.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);
                row.setLayoutParams(tableRowParams);
                row.setOrientation(LinearLayout.HORIZONTAL);

                TextView tv = new TextView(getContext());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                tv.setLayoutParams(lp);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                tv.setText(HtmlCompat.fromHtml("<span style=\"color:#000000;\">Brand</span>", HtmlCompat.FROM_HTML_MODE_LEGACY));
                row.addView(tv);

                tv = new TextView(getContext());
                lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(110, 0, 0, 0);
                tv.setLayoutParams(lp);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                tv.setText(val);
                row.addView(tv);
                tl.addView(row);
            }
        }

        if (!featureFlag){
            view.findViewById(R.id.features).setVisibility(View.GONE);
        }

    }

    private void creategallery(LinearLayout gallery, View view) throws JSONException {
        JSONArray urls;
        try {
            urls = data.getJSONObject("Item").getJSONArray("PictureURL");
        }catch (Exception e) {
            urls = null;
        }
        if (urls!=null) {
            for (int i = 0; i < urls.length(); i++) {
                ImageView iv = new ImageView(getContext());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(1000, 1000);
                lp.setMargins(15, 15, 15, 15);
                iv.setLayoutParams(lp);
                Picasso.with(getContext()).load(urls.getString(i)).resize(1000, 1000).into(iv);
                gallery.addView(iv);
            }
        }
        TextView title = view.findViewById(R.id.title);
        title.setText(HtmlCompat.fromHtml("<span style=\"color:#000000;\">"+getArguments().getString("title")+"</span>", HtmlCompat.FROM_HTML_MODE_LEGACY));
        TextView price = view.findViewById(R.id.price);
        price.setText(HtmlCompat.fromHtml("<b style='color:#a8b871;'>$"+getArguments().getString("price")+"</b>", HtmlCompat.FROM_HTML_MODE_LEGACY));
        price.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        TextView ship = view.findViewById(R.id.ship);
        if (Double.parseDouble(getArguments().getString("shipping"))==0.0) {
            ship.setText(HtmlCompat.fromHtml("FREE Shipping", HtmlCompat.FROM_HTML_MODE_LEGACY));
        }else{
            ship.setText(HtmlCompat.fromHtml("Ships for $"+getArguments().getString("shipping"), HtmlCompat.FROM_HTML_MODE_LEGACY));
        }
    }
}

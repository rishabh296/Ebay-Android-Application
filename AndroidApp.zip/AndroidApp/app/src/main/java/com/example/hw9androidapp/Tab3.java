package com.example.hw9androidapp;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.text.HtmlCompat;
import androidx.fragment.app.Fragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

public class Tab3 extends Fragment {

    private JSONObject data;
    private String prodId;
    private TextView sample;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab3, container, false);
        try {
            if (getArguments() != null) {
                this.prodId = getArguments().getString("prodId");
                this.data = new JSONObject(getArguments().getString("response"));
                embedInfo(view);
            }
        }catch (Exception e){
            System.out.println("Error in Tab3.java");
            e.printStackTrace();
        }
        return view;
    }

    private void embedInfo(View view) throws JSONException {
        JSONObject json = new JSONObject(getArguments().getString("shippingInfo"));
        LinearLayout shipInfo = view.findViewById(R.id.shipsInfo);

        if (json!=null && json.length()>0) {
            shipInfo.setVisibility(View.VISIBLE);
            Iterator<String> iter = json.keys();
            while (iter.hasNext()) {
                String key = iter.next();
//                if (key.equals("shippingServiceCost")) {
//
//                    continue;
//                }
                String value = json.getJSONArray(key).getString(0);
                String name = String.join(" ", key.split("(?=\\p{Lu})"));
                name = name.substring(0, 1).toUpperCase() + name.substring(1);
                TextView tv = new TextView(getContext());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(60, 0, 0, 50);
                tv.setLayoutParams(lp);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                if (key.equals("shippingServiceCost")) {
                    try {
                        tv.setText(HtmlCompat.fromHtml("<b>\u2022 " + name + "</b> : " + json.getJSONArray(key).getJSONObject(0).getString("@currencyId") + " " + json.getJSONArray(key).getJSONObject(0).getString("__value__"), HtmlCompat.FROM_HTML_MODE_LEGACY));
                    }catch (Exception e){
                        continue;
                    }
                }else if (value.equals("true")) {
                    tv.setText(HtmlCompat.fromHtml("<b>\u2022 " + name + "</b> : Yes", HtmlCompat.FROM_HTML_MODE_LEGACY));
                }else if(value.equals("false")){
                    tv.setText(HtmlCompat.fromHtml("<b>\u2022 " + name + "</b> : No", HtmlCompat.FROM_HTML_MODE_LEGACY));
                }else{
                    tv.setText(HtmlCompat.fromHtml("<b>\u2022 " + name + "</b> : " + value, HtmlCompat.FROM_HTML_MODE_LEGACY));
                }
                shipInfo.addView(tv);
            }
        }else {
            shipInfo.setVisibility(View.GONE);
        }
    }

}

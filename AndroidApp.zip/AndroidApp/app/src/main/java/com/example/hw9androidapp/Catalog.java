package com.example.hw9androidapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.text.HtmlCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.ActionBar;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Catalog extends AppCompatActivity {

    private RequestQueue mQue; private Toolbar toolbar;
    private String url; private TextView resp;
    private List<Map<String, String>> data; Boolean noResult;
    private Boolean swipperFlag2 = false; private Boolean swipperFlag = false; private Integer total;

    RecyclerView recycler;
    MyAdapter adapter;
    SwipeRefreshLayout swipeRefreshLayout;
    SwipeRefreshLayout swipeRefreshLayout2;
    LinearLayout loading, content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_catalog);
            prepareActionBar();

            loading = findViewById(R.id.loading);
            loading.setVisibility(View.VISIBLE);

            url = getIntent().getStringExtra("url");
            mQue = Volley.newRequestQueue(this);
            swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeLayout);
            swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    noResult = false;
                    swipperFlag = true;
                    callServer(url);
                }
            });
            swipeRefreshLayout2 = (SwipeRefreshLayout) findViewById(R.id.swipeLayout2);
            swipeRefreshLayout2.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    //                noResult=false;
                    swipperFlag2 = true;
                    callServer(url);
                }
            });
            noResult = false;
            callServer(url);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private ArrayList<Model> getData() {
        System.out.println("Globally Data length is - "+data.size());
        ArrayList<Model> models = new ArrayList<Model>();
        for (int i=0 ;i<data.size();i++){
            Map<String, String> item = data.get(i);
            Model m = new Model();
            m.setTitle(item.get("title"));
            m.setPrice(item.get("price"));
            m.setShipping(item.get("shipping"));
            m.setCondition(item.get("condition"));
            m.setTop_rated(item.get("top_rated"));
            m.setImg(item.get("url"));
            m.setItemUrl(item.get("itemUrl"));
            m.setProdId(item.get("prodId"));
            m.setShippingInfo(item.get("shippingInfo"));
            models.add(m);
        }
        return models;
    }

    private void prepareActionBar() {
        toolbar = findViewById(R.id.abar);
        toolbar.setTitle("Search Results");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void callServer(String url) {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            handleResponse(response);
                            if(noResult){
                                noResultEnable();
                            }
                        } catch (Exception e) {
                            System.out.println("Issue While getting JSON in callServer");
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQue.add(request);
    }

    private void noResultEnable() {
        LinearLayout nr = findViewById(R.id.noresult);
        nr.setVisibility(View.VISIBLE);
        if(swipperFlag2){
            swipperFlag2=false;
            swipeRefreshLayout2.setRefreshing(false);
        }
        loading.setVisibility(View.GONE);
        Toast.makeText(getApplicationContext(), "No Records", Toast.LENGTH_SHORT).show();
    }

    private void handleResponse(JSONObject response) throws JSONException {
        total = Integer.parseInt(response.getJSONArray("findItemsAdvancedResponse").getJSONObject(0).getJSONArray("paginationOutput").getJSONObject(0).getJSONArray("totalEntries").getString(0));
        int show = Math.min(total,50);
        System.out.println("Got catalog results - "+show);
        if (show==0){
            noResult=true;
            return;
        }else {
            noResult=false;
            TextView st = findViewById(R.id.searchTitle);
            st.setText(HtmlCompat.fromHtml("<b>Showing <span style=\"color:#2d66f7; \"><b>"+show+"</b></span> results for <span style=\"color:#2d66f7;\"><b>"+getIntent().getStringExtra("key")+"</b></span></b>", HtmlCompat.FROM_HTML_MODE_LEGACY));
        }

        JSONArray objects = response.getJSONArray("findItemsAdvancedResponse").getJSONObject(0).getJSONArray("searchResult").getJSONObject(0).getJSONArray("item");
        int count=0;
        data = new ArrayList<Map<String,String>>();
        for(int i=0;i<objects.length();i++){
            Map<String,String> parsed = new HashMap<String, String>();
            JSONObject item = objects.getJSONObject(i);
            try{

                parsed.put("title" , item.getJSONArray("title").getString(0));
                parsed.put("price", item.getJSONArray("sellingStatus").getJSONObject(0).getJSONArray("convertedCurrentPrice").getJSONObject(0).getString("__value__"));
                parsed.put("prodId", item.getJSONArray("itemId").getString(0));
                parsed.put("shipping", item.getJSONArray("shippingInfo").getJSONObject(0).getJSONArray("shippingServiceCost").getJSONObject(0).getString("__value__"));
            }catch (Exception e){
                continue;
            }

            try {
                parsed.put("url", item.getJSONArray("galleryURL").getString(0));
            }catch (Exception e){
                parsed.put("url", "");
            }
            try {
                parsed.put("top_rated", item.getJSONArray("topRatedListing").getString(0));
            }catch (Exception e){
                parsed.put("top_rated", "false");
            }
            try {
                parsed.put("shippingInfo", item.getJSONArray("shippingInfo").getJSONObject(0).toString());
            }catch (Exception e){
                parsed.put("shippingInfo", "");
            }
            try {
                parsed.put("itemUrl", item.getJSONArray("viewItemURL").getString(0));
            }catch (Exception e){
                parsed.put("itemUrl", "");
            }
            try {
                parsed.put("condition", item.getJSONArray("condition").getJSONObject(0).getJSONArray("conditionDisplayName").getString(0));
            }catch (Exception e){
                parsed.put("condition", "");
            }




            data.add(parsed);
            count+=1;
            if (count==50){
                break;
            }

        }
        recycler = findViewById(R.id.recycler);
        recycler.setHasFixedSize(true);
        adapter = new MyAdapter(this, getData());
        recycler.setAdapter(adapter);
        GridLayoutManager grid = new GridLayoutManager(this,2, GridLayoutManager.VERTICAL, false);
        recycler.setLayoutManager(grid);
        recycler.addItemDecoration(new DividerItemDecoration(recycler.getContext(), DividerItemDecoration.VERTICAL));
        recycler.addItemDecoration(new DividerItemDecoration(recycler.getContext(), DividerItemDecoration.HORIZONTAL));

        if(swipperFlag){
            swipperFlag=false;
            swipeRefreshLayout.setRefreshing(false);
        }
        loading.setVisibility(View.GONE);
    }
}
package com.example.hw9androidapp;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.text.HtmlCompat;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

public class Tab2 extends Fragment {

    private JSONObject data;
    private String prodId;
    private TextView sample;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.tab2, container, false);
        try{
//            this.sample = (TextView) view.findViewById(R.id.sampleText2);
            if(getArguments()!=null){
                this.prodId = getArguments().getString("prodId");
                this.data = new JSONObject(getArguments().getString("response"));
//                sample.setText(this.data.toString());
                embedInfo(view);
            }
        }catch (Exception e){
            System.out.println("Error in Tab2.java");
            e.printStackTrace();
        }
        return view;
    }

    private void embedInfo(View view) throws JSONException {
        JSONObject sellers;
        JSONObject returns;
        try {
            sellers = data.getJSONObject("Item").getJSONObject("Seller");
        }catch (Exception e){
            e.printStackTrace();
            sellers = null;
        }
        try {
            returns = data.getJSONObject("Item").getJSONObject("ReturnPolicy");
        }catch (Exception e){
            e.printStackTrace();
            returns = null;
        }


        LinearLayout sellerInfo = view.findViewById(R.id.sellerInfo);
        LinearLayout returnPol = view.findViewById(R.id.returnPolicies);

        Iterator<String> iter;
        if (sellers!=null && sellers.length()>0) {
            sellerInfo.setVisibility(View.VISIBLE);
            iter = sellers.keys();
            while (iter.hasNext()) {
                String key = iter.next();
                String value = sellers.getString(key);
                String name = String.join(" ", key.split("(?=\\p{Lu})"));
                name = name.substring(0, 1).toUpperCase() + name.substring(1);
                TextView tv = new TextView(getContext());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(60, 0, 0, 50);
                tv.setLayoutParams(lp);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                tv.setText(HtmlCompat.fromHtml("<b>\u2022 " + name + "</b> : " + value, HtmlCompat.FROM_HTML_MODE_LEGACY));
                sellerInfo.addView(tv);
            }
        }else {
            sellerInfo.setVisibility(View.GONE);
        }

        if (returns!=null && returns.length()>0) {
            returnPol.setVisibility(View.VISIBLE);
            iter = returns.keys();
            while (iter.hasNext()){
                String key = iter.next();
                String value = returns.getString(key);
                String name = String.join(" ",key.split("(?=\\p{Lu})"));
                name = name.substring(0, 1).toUpperCase() + name.substring(1);
                TextView tv = new TextView(getContext());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(60, 0, 0, 50);
                tv.setLayoutParams(lp);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP,16);
                tv.setText(HtmlCompat.fromHtml("<b>\u2022 "+name+"</b> : "+value, HtmlCompat.FROM_HTML_MODE_LEGACY));
                returnPol.addView(tv);
            }
        }else {
            returnPol.setVisibility(View.GONE);
        }
    }

}

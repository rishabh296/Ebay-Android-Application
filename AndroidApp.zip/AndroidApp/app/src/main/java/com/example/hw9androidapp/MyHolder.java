package com.example.hw9androidapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyHolder extends RecyclerView.ViewHolder{

    ImageView img;
    TextView title,condition, top_rated, shipping, price;

    public MyHolder(@NonNull View itemView) {
        super(itemView);

        this.img = itemView.findViewById(R.id.img);
        this.title = itemView.findViewById(R.id.title);
        this.shipping = itemView.findViewById(R.id.shipping);
        this.top_rated = itemView.findViewById(R.id.top_rated);
        this.condition = itemView.findViewById(R.id.condition);
        this.price = itemView.findViewById(R.id.price);
    }
}

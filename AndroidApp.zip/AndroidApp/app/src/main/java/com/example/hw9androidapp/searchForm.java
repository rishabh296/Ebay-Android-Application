package com.example.hw9androidapp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.util.TypedValue;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class searchForm extends AppCompatActivity {

    private Toolbar toolbar; private EditText key; private EditText price1; private EditText price2;
    private TextView keyError; private TextView priceError; private CheckBox New; private CheckBox used;
    private CheckBox acceptable; private Spinner sort; private Object[] attList = new Object[5];
    private RequestQueue mQue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            setTheme(R.style.AppTheme);
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_search_form);

            toolbar = findViewById(R.id.abar);
            toolbar.setTitle("eBay Catalog Search");

            keyError = (TextView) findViewById(R.id.keyError);
            priceError = (TextView) findViewById(R.id.priceError);
            key = (EditText) findViewById(R.id.key);
            price1 = (EditText) findViewById(R.id.price1);
            price2 = (EditText) findViewById(R.id.price2);
            New = (CheckBox) findViewById(R.id.New);
            used = (CheckBox) findViewById(R.id.used);
            acceptable = (CheckBox) findViewById(R.id.acceptable);
            sort = (Spinner) findViewById(R.id.sort);
            attList[0] = price1;
            attList[1] = price2;
            attList[2] = New;
            attList[3] = used;
            attList[4] = acceptable;
            mQue = Volley.newRequestQueue(this);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void onSearch(View view) {
        try {
            Boolean f1=false; Boolean f2=false;
            if (key.getText().toString().length() == 0) {
                keyError.setText(R.string.kerror);
                keyError.setVisibility(View.VISIBLE);
                f1=true;
            }else{
                keyError.setVisibility(View.GONE);
            }
            if ((price1.getText().toString().length()>0 &&  Double.parseDouble(price1.getText().toString())<0) || (price2.getText().toString().length()>0 &&  Double.parseDouble(price2.getText().toString())<0)
                    || (price1.getText().toString().length()>0 && price2.getText().toString().length()>0 && Double.parseDouble(price2.getText().toString())<=Double.parseDouble(price1.getText().toString()))){
                priceError.setVisibility(View.VISIBLE);
                f2=true;
            }else{
                priceError.setVisibility(View.GONE);
            }
            if (!f1 && !f2){
                String url = createUrl();
                Intent intent = new Intent(getApplicationContext(), Catalog.class);
                intent.putExtra("url", url);
                intent.putExtra("key", key.getText().toString());
                startActivity(intent);
            }else{
                Toast.makeText(getApplicationContext(), "Please fix all fields with errors",Toast.LENGTH_SHORT).show();
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private String createUrl() {
        String url = "https://angproj8.wl.r.appspot.com/ebayapi?key="+key.getText().toString();
        Map<String, String> map = new HashMap<String, String>();
        map.put("Best Match", "best"); map.put("Price: highest first", "phigh"); map.put("Price + Shipping: Highest first", "pshigh"); map.put("Price + Shipping: Lowest first", "pslow");

        if (price1.getText().toString().length()>0){url+="&price1="+price1.getText().toString();}
        if (price2.getText().toString().length()>0){url+="&price2="+price2.getText().toString();}
        if (New.isChecked()){url+="&new="+New.getText().toString();}
        if (used.isChecked()){url+="&used="+used.getText().toString();}
        if (acceptable.isChecked()){url+="&unspecified="+acceptable.getText().toString();}
        if (sort.getSelectedItem().toString().length()>0){url+="&sort="+map.get(sort.getSelectedItem().toString());}
        return url;
    }

    public void clear(View view) {
        key.setText(""); price1.setText(""); price2.setText("");
        if(New.isChecked()){
            New.toggle();
        }if(used.isChecked()){
            used.toggle();
        }if(acceptable.isChecked()){
            acceptable.toggle();
        }
        sort.setSelection(0,true);
        priceError.setVisibility(View.GONE);
        keyError.setVisibility(View.GONE);

    }

}